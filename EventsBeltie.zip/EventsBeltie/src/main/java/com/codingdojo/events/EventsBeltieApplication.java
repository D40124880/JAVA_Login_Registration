package com.codingdojo.events;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventsBeltieApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventsBeltieApplication.class, args);
	}
}
